import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const EditorPage(),
    );
  }
}

class EditorPage extends StatefulWidget {
  const EditorPage({super.key});

  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late WebViewController _web;

  final htmlCtrl = TextEditingController(text: '<h1>Hello World</h1>');
  final cssCtrl = TextEditingController(text: 'body { color: white; }');
  final jsCtrl = TextEditingController(text: 'console.log("JS OK");');

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  void livePreview() {
    final fullHtml = '''
<!DOCTYPE html>
<html>
<head>
<style>${cssCtrl.text}</style>
</head>
<body>
${htmlCtrl.text}
<script>${jsCtrl.text}</script>
</body>
</html>
''';

    final uri = Uri.dataFromString(
      fullHtml,
      mimeType: 'text/html',
      encoding: utf8,
    );

    _web.loadRequest(uri);
  }

  Widget editor(String label, TextEditingController c) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: TextField(
        controller: c,
        onChanged: (_) => livePreview(),
        maxLines: null,
        expands: true,
        style: const TextStyle(fontFamily: 'monospace'),
        decoration: InputDecoration(
          border: const OutlineInputBorder(),
          labelText: label,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('VS Code Mini'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'HTML'),
            Tab(text: 'CSS'),
            Tab(text: 'JS'),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            flex: 3,
            child: TabBarView(
              controller: _tabController,
              children: [
                editor('HTML', htmlCtrl),
                editor('CSS', cssCtrl),
                editor('JavaScript', jsCtrl),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: WebView(
              javascriptMode: JavascriptMode.unrestricted,
              onWebViewCreated: (c) {
                _web = c;
                livePreview();
              },
            ),
          ),
        ],
      ),
    );
  }
}
